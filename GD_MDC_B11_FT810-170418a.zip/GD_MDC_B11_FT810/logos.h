#define LOAD_ASSETS()  GD.safeload("logos.gd2");
#define MULTI_HANDLE 0
#define MULTI_WIDTH 45
#define MULTI_HEIGHT 135
#define MULTI_CELLS 1
#define TEMPO_HANDLE 1
#define TEMPO_WIDTH 84
#define TEMPO_HEIGHT 240
#define TEMPO_CELLS 1
#define ICRADIO_HANDLE 2
#define ICRADIO_WIDTH 64
#define ICRADIO_HEIGHT 512
#define ICRADIO_CELLS 1
#define ICRADIO2_HANDLE 3
#define ICRADIO2_WIDTH 64
#define ICRADIO2_HEIGHT 512
#define ICRADIO2_CELLS 1
#define LEDS_HANDLE 4
#define LEDS_WIDTH 24
#define LEDS_HEIGHT 48
#define LEDS_CELLS 1
#define ICRADIO3_HANDLE 5
#define ICRADIO3_WIDTH 64
#define ICRADIO3_HEIGHT 576
#define ICRADIO3_CELLS 1
#define MP_HANDLE 6
#define MP_WIDTH 84
#define MP_HEIGHT 840
#define MP_CELLS 1
#define CUCU1_HANDLE 7
#define CUCU1_WIDTH 100
#define CUCU1_HEIGHT 100
#define CUCU1_CELLS 1
#define CUCU2_HANDLE 8
#define CUCU2_WIDTH 210
#define CUCU2_HEIGHT 350
#define CUCU2_CELLS 1
#define CUCU3_HANDLE 9
#define CUCU3_WIDTH 250
#define CUCU3_HEIGHT 250
#define CUCU3_CELLS 1
#define ASSETS_END 512508UL
static const shape_t MULTI_SHAPE = {0, 45, 135, 0};
static const shape_t TEMPO_SHAPE = {1, 84, 240, 0};
static const shape_t ICRADIO_SHAPE = {2, 64, 512, 0};
static const shape_t ICRADIO2_SHAPE = {3, 64, 512, 0};
static const shape_t LEDS_SHAPE = {4, 24, 48, 0};
static const shape_t ICRADIO3_SHAPE = {5, 64, 576, 0};
static const shape_t MP_SHAPE = {6, 84, 840, 0};
static const shape_t CUCU1_SHAPE = {7, 100, 100, 0};
static const shape_t CUCU2_SHAPE = {8, 210, 350, 0};
static const shape_t CUCU3_SHAPE = {9, 250, 250, 0};
